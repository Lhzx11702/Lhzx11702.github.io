import { World } from "./world";
import { isSolid } from "./blocks";

export const PLAYER_HALF_WIDTH = 0.3;
export const PLAYER_HEIGHT = 1.75;
export const EYE_HEIGHT = 1.62;
export const GRAVITY = 26;
export const JUMP_SPEED = 8.4;
export const WALK_SPEED = 4.3;

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

// 方块以整数坐标为中心,占据 [n-0.5, n+0.5] 的空间,
// 因此判断某个世界坐标落在哪个方块内时需要使用四舍五入而非向下取整。
function blockIndex(v: number): number {
  return Math.floor(v + 0.5);
}

function checkCollision(world: World, x: number, y: number, z: number): boolean {
  const minX = blockIndex(x - PLAYER_HALF_WIDTH);
  const maxX = blockIndex(x + PLAYER_HALF_WIDTH);
  const minY = blockIndex(y);
  const maxY = blockIndex(y + PLAYER_HEIGHT);
  const minZ = blockIndex(z - PLAYER_HALF_WIDTH);
  const maxZ = blockIndex(z + PLAYER_HALF_WIDTH);
  for (let bx = minX; bx <= maxX; bx++) {
    for (let by = minY; by <= maxY; by++) {
      for (let bz = minZ; bz <= maxZ; bz++) {
        if (isSolid(world.getBlock(bx, by, bz))) return true;
      }
    }
  }
  return false;
}

export interface MoveResult {
  pos: Vec3;
  collidedY: boolean;
  collidedYNegative: boolean;
}

export function tryMove(world: World, pos: Vec3, dx: number, dy: number, dz: number): MoveResult {
  let x = pos.x;
  let y = pos.y;
  let z = pos.z;
  let collidedY = false;
  let collidedYNegative = false;

  if (dx !== 0) {
    const nx = x + dx;
    if (!checkCollision(world, nx, y, z)) {
      x = nx;
    }
  }
  if (dz !== 0) {
    const nz = z + dz;
    if (!checkCollision(world, x, y, nz)) {
      z = nz;
    }
  }
  if (dy !== 0) {
    const ny = y + dy;
    if (!checkCollision(world, x, ny, z)) {
      y = ny;
    } else {
      collidedY = true;
      if (dy < 0) collidedYNegative = true;
    }
  }
  return { pos: { x, y, z }, collidedY, collidedYNegative };
}

export function isPositionFree(world: World, pos: Vec3): boolean {
  return !checkCollision(world, pos.x, pos.y, pos.z);
}
