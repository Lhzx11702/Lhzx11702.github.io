export interface InputState {
  moveX: number; // -1..1 左右
  moveY: number; // -1..1 前后 (前为正)
  lookDX: number; // 累计视角增量,读取后需重置
  lookDY: number;
  jump: boolean;
  breaking: boolean;
  place: boolean; // 边沿触发,处理后需重置为 false
}

export function createInputState(): InputState {
  return {
    moveX: 0,
    moveY: 0,
    lookDX: 0,
    lookDY: 0,
    jump: false,
    breaking: false,
    place: false,
  };
}
