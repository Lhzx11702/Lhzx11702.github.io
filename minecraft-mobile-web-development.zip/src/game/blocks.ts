// 方块类型定义
export enum BlockType {
  AIR = 0,
  GRASS = 1,
  DIRT = 2,
  STONE = 3,
  SAND = 4,
  WOOD = 5,
  LEAVES = 6,
  WATER = 7,
  BEDROCK = 8,
  PLANK = 9,
}

export interface BlockInfo {
  name: string;
  icon: string; // 贴图路径,用于 HUD 图标
  hardness: number; // 挖掘所需时间(秒)
  placeable: boolean;
}

export const BLOCK_INFO: Record<BlockType, BlockInfo> = {
  [BlockType.AIR]: { name: "空气", icon: "", hardness: 0, placeable: false },
  [BlockType.GRASS]: { name: "草方块", icon: "/textures/grass_side.png", hardness: 0.6, placeable: true },
  [BlockType.DIRT]: { name: "泥土", icon: "/textures/dirt.png", hardness: 0.5, placeable: true },
  [BlockType.STONE]: { name: "石头", icon: "/textures/stone.png", hardness: 1.2, placeable: true },
  [BlockType.SAND]: { name: "沙子", icon: "/textures/sand.png", hardness: 0.5, placeable: true },
  [BlockType.WOOD]: { name: "原木", icon: "/textures/wood_side.png", hardness: 0.9, placeable: true },
  [BlockType.LEAVES]: { name: "树叶", icon: "/textures/leaves.png", hardness: 0.2, placeable: true },
  [BlockType.WATER]: { name: "水", icon: "", hardness: 0, placeable: false },
  [BlockType.BEDROCK]: { name: "基岩", icon: "/textures/stone.png", hardness: 999, placeable: false },
  [BlockType.PLANK]: { name: "木板", icon: "/textures/wood_top.png", hardness: 0.8, placeable: true },
};

export const HOTBAR_BLOCKS: BlockType[] = [
  BlockType.GRASS,
  BlockType.DIRT,
  BlockType.STONE,
  BlockType.SAND,
  BlockType.WOOD,
  BlockType.LEAVES,
  BlockType.PLANK,
];

export function isSolid(type: BlockType): boolean {
  return type !== BlockType.AIR && type !== BlockType.WATER;
}
