import * as THREE from "three";
import { World } from "./world";
import { Materials } from "./textures";
import { BlockType } from "./blocks";

const dummy = new THREE.Object3D();

export function buildInstancedMeshes(
  world: World,
  materials: Materials,
  geometry: THREE.BoxGeometry
): THREE.InstancedMesh[] {
  const groups = new Map<BlockType, { x: number; y: number; z: number }[]>();
  for (const b of world.visibleBlocks.values()) {
    let arr = groups.get(b.type);
    if (!arr) {
      arr = [];
      groups.set(b.type, arr);
    }
    arr.push(b);
  }

  const meshes: THREE.InstancedMesh[] = [];
  for (const [type, list] of groups) {
    const mat = materials.byType[type];
    if (!mat || list.length === 0) continue;
    const mesh = new THREE.InstancedMesh(geometry, mat as THREE.Material | THREE.Material[], list.length);
    mesh.userData.blockType = type;
    for (let i = 0; i < list.length; i++) {
      dummy.position.set(list[i].x, list[i].y, list[i].z);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.frustumCulled = false;
    if (type === BlockType.WATER) {
      mesh.renderOrder = 1;
    }
    meshes.push(mesh);
  }
  return meshes;
}
