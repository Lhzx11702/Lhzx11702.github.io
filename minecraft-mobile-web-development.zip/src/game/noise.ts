import { createNoise2D } from "simplex-noise";

// 简单的可复现随机数生成器 (mulberry32)
function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function createSeededRandom(seed: number) {
  return mulberry32(seed);
}

export function createFractalNoise2D(seed: number) {
  const rng = mulberry32(seed);
  const noise2D = createNoise2D(rng);
  return function fractal(x: number, z: number, octaves = 4, persistence = 0.5, scale = 0.02): number {
    let total = 0;
    let frequency = scale;
    let amplitude = 1;
    let maxValue = 0;
    for (let i = 0; i < octaves; i++) {
      total += noise2D(x * frequency, z * frequency) * amplitude;
      maxValue += amplitude;
      amplitude *= persistence;
      frequency *= 2;
    }
    return total / maxValue; // -1..1
  };
}
