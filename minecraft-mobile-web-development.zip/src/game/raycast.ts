import * as THREE from "three";
import { World } from "./world";
import { BlockType } from "./blocks";

export interface RaycastResult {
  block: { x: number; y: number; z: number };
  place: { x: number; y: number; z: number };
  type: BlockType;
}

const _pos = new THREE.Vector3();

export function raycastVoxel(
  origin: THREE.Vector3,
  dir: THREE.Vector3,
  world: World,
  maxDist = 6,
  step = 0.04
): RaycastResult | null {
  let lastVoxel: { x: number; y: number; z: number } | null = null;
  for (let t = 0; t <= maxDist; t += step) {
    _pos.copy(origin).addScaledVector(dir, t);
    const vx = Math.round(_pos.x);
    const vy = Math.round(_pos.y);
    const vz = Math.round(_pos.z);
    const type = world.getBlock(vx, vy, vz);
    if (type !== BlockType.AIR && type !== BlockType.WATER) {
      return {
        block: { x: vx, y: vy, z: vz },
        place: lastVoxel ?? { x: vx, y: vy + 1, z: vz },
        type,
      };
    }
    if (!lastVoxel || lastVoxel.x !== vx || lastVoxel.y !== vy || lastVoxel.z !== vz) {
      lastVoxel = { x: vx, y: vy, z: vz };
    }
  }
  return null;
}
