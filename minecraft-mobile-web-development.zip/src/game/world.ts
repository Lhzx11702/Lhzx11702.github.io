import { BlockType, isSolid } from "./blocks";
import { createFractalNoise2D, createSeededRandom } from "./noise";

export const WORLD_RADIUS = 30; // 世界从 -R 到 +R
export const WATER_LEVEL = 8;
export const MIN_Y = 0;

function key(x: number, y: number, z: number): string {
  return x + "," + y + "," + z;
}

export interface VisibleBlock {
  x: number;
  y: number;
  z: number;
  type: BlockType;
}

export class World {
  private heightCache = new Map<string, number>();
  private treeBlocks = new Map<string, BlockType>();
  private overrides = new Map<string, BlockType>();
  public visibleBlocks = new Map<string, VisibleBlock>();
  private noise: (x: number, z: number, o?: number, p?: number, s?: number) => number;
  private detailNoise: (x: number, z: number, o?: number, p?: number, s?: number) => number;
  private seed: number;

  constructor(seed = Date.now() % 100000) {
    this.seed = seed;
    this.noise = createFractalNoise2D(seed);
    this.detailNoise = createFractalNoise2D(seed + 999);
  }

  private hKey(x: number, z: number) {
    return x + "_" + z;
  }

  heightAt(x: number, z: number): number {
    const hk = this.hKey(x, z);
    const cached = this.heightCache.get(hk);
    if (cached !== undefined) return cached;
    const n = this.noise(x, z, 4, 0.5, 0.015);
    const detail = this.detailNoise(x, z, 2, 0.5, 0.08) * 2;
    const h = Math.round(10 + n * 9 + detail);
    const clamped = Math.max(2, Math.min(28, h));
    this.heightCache.set(hk, clamped);
    return clamped;
  }

  private inBounds(x: number, z: number) {
    return x >= -WORLD_RADIUS && x <= WORLD_RADIUS && z >= -WORLD_RADIUS && z <= WORLD_RADIUS;
  }

  getBlock(x: number, y: number, z: number): BlockType {
    if (!this.inBounds(x, z)) return BlockType.AIR;
    if (y < MIN_Y) return BlockType.BEDROCK;
    const k = key(x, y, z);
    const ov = this.overrides.get(k);
    if (ov !== undefined) return ov;
    const tb = this.treeBlocks.get(k);
    if (tb !== undefined) return tb;
    const h = this.heightAt(x, z);
    if (y > h) {
      if (y <= WATER_LEVEL) return BlockType.WATER;
      return BlockType.AIR;
    }
    if (y === 0) return BlockType.BEDROCK;
    const isBeach = h <= WATER_LEVEL + 1;
    if (y === h) return isBeach ? BlockType.SAND : BlockType.GRASS;
    if (y > h - 4) return isBeach ? BlockType.SAND : BlockType.DIRT;
    return BlockType.STONE;
  }

  setBlock(x: number, y: number, z: number, type: BlockType) {
    this.overrides.set(key(x, y, z), type);
    this.refreshAround(x, y, z);
  }

  private refreshAround(x: number, y: number, z: number) {
    const positions: [number, number, number][] = [
      [x, y, z],
      [x + 1, y, z],
      [x - 1, y, z],
      [x, y + 1, z],
      [x, y - 1, z],
      [x, y, z + 1],
      [x, y, z - 1],
    ];
    for (const [px, py, pz] of positions) this.checkAndUpdateVisibility(px, py, pz);
  }

  private checkAndUpdateVisibility(x: number, y: number, z: number) {
    const k = key(x, y, z);
    if (y < MIN_Y || y > 200) {
      this.visibleBlocks.delete(k);
      return;
    }
    const t = this.getBlock(x, y, z);
    if (t === BlockType.AIR) {
      this.visibleBlocks.delete(k);
      return;
    }
    const neighbors: [number, number, number][] = [
      [x + 1, y, z],
      [x - 1, y, z],
      [x, y + 1, z],
      [x, y - 1, z],
      [x, y, z + 1],
      [x, y, z - 1],
    ];
    let exposed = false;
    for (const [nx, ny, nz] of neighbors) {
      const nt = this.getBlock(nx, ny, nz);
      if (nt === BlockType.AIR || (nt === BlockType.WATER && t !== BlockType.WATER)) {
        exposed = true;
        break;
      }
    }
    if (exposed) {
      this.visibleBlocks.set(k, { x, y, z, type: t });
    } else {
      this.visibleBlocks.delete(k);
    }
  }

  private generateTrees() {
    const rng = createSeededRandom(this.seed + 12345);
    const spacing = 4;
    for (let x = -WORLD_RADIUS + 2; x <= WORLD_RADIUS - 2; x += spacing) {
      for (let z = -WORLD_RADIUS + 2; z <= WORLD_RADIUS - 2; z += spacing) {
        const ox = Math.floor(rng() * spacing);
        const oz = Math.floor(rng() * spacing);
        const tx = x + ox;
        const tz = z + oz;
        if (!this.inBounds(tx, tz)) continue;
        if (rng() > 0.22) continue;
        const h = this.heightAt(tx, tz);
        if (h <= WATER_LEVEL + 1) continue;
        const trunkHeight = 4 + Math.floor(rng() * 2);
        for (let dy = 1; dy <= trunkHeight; dy++) {
          this.treeBlocks.set(key(tx, h + dy, tz), BlockType.WOOD);
        }
        // 树冠
        const topY = h + trunkHeight;
        for (let layer = -2; layer <= 1; layer++) {
          const radius = layer >= 1 ? 1 : 2;
          for (let dx = -radius; dx <= radius; dx++) {
            for (let dz = -radius; dz <= radius; dz++) {
              if (Math.abs(dx) === radius && Math.abs(dz) === radius && radius === 2) continue;
              if (dx === 0 && dz === 0 && layer < 1) continue;
              const lx = tx + dx;
              const lz = tz + dz;
              const ly = topY + layer;
              const k = key(lx, ly, lz);
              if (!this.treeBlocks.has(k)) {
                this.treeBlocks.set(k, BlockType.LEAVES);
              }
            }
          }
        }
      }
    }
  }

  generate() {
    // 预热高度缓存
    for (let x = -WORLD_RADIUS; x <= WORLD_RADIUS; x++) {
      for (let z = -WORLD_RADIUS; z <= WORLD_RADIUS; z++) {
        this.heightAt(x, z);
      }
    }
    this.generateTrees();

    for (let x = -WORLD_RADIUS; x <= WORLD_RADIUS; x++) {
      for (let z = -WORLD_RADIUS; z <= WORLD_RADIUS; z++) {
        const h = this.heightAt(x, z);
        const startY = Math.max(MIN_Y, h - 5);
        for (let y = startY; y <= h; y++) {
          this.checkAndUpdateVisibility(x, y, z);
        }
        if (h < WATER_LEVEL) {
          for (let y = h + 1; y <= WATER_LEVEL; y++) {
            this.checkAndUpdateVisibility(x, y, z);
          }
        }
      }
    }
    for (const k of this.treeBlocks.keys()) {
      const [x, y, z] = k.split(",").map(Number);
      this.checkAndUpdateVisibility(x, y, z);
    }
  }

  isSolidAt(x: number, y: number, z: number): boolean {
    return isSolid(this.getBlock(Math.round(x), Math.round(y), Math.round(z)));
  }

  findSpawn(): { x: number; y: number; z: number } {
    let x = 0;
    let z = 0;
    let h = this.heightAt(x, z);
    let tries = 0;
    while (h <= WATER_LEVEL + 1 && tries < 50) {
      x += 1;
      z += 1;
      h = this.heightAt(x, z);
      tries++;
    }
    return { x: x, y: h + 0.6, z: z };
  }
}
