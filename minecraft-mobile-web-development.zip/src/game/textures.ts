import * as THREE from "three";
import { BlockType } from "./blocks";

const loader = new THREE.TextureLoader();

function loadTex(path: string): THREE.Texture {
  const tex = loader.load(path);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.generateMipmaps = false;
  return tex;
}

export interface Materials {
  byType: Partial<Record<BlockType, THREE.Material | THREE.Material[]>>;
}

export function buildMaterials(): Materials {
  const grassTop = loadTex("/textures/grass_top.png");
  const grassSide = loadTex("/textures/grass_side.png");
  const dirt = loadTex("/textures/dirt.png");
  const stone = loadTex("/textures/stone.png");
  const sand = loadTex("/textures/sand.png");
  const woodSide = loadTex("/textures/wood_side.png");
  const woodTop = loadTex("/textures/wood_top.png");
  const leaves = loadTex("/textures/leaves.png");

  const matGrassTop = new THREE.MeshLambertMaterial({ map: grassTop });
  const matGrassSide = new THREE.MeshLambertMaterial({ map: grassSide });
  const matDirt = new THREE.MeshLambertMaterial({ map: dirt });
  const matStone = new THREE.MeshLambertMaterial({ map: stone });
  const matSand = new THREE.MeshLambertMaterial({ map: sand });
  const matWoodSide = new THREE.MeshLambertMaterial({ map: woodSide });
  const matWoodTop = new THREE.MeshLambertMaterial({ map: woodTop });
  const matLeaves = new THREE.MeshLambertMaterial({ map: leaves, transparent: false });
  const matPlank = new THREE.MeshLambertMaterial({ map: woodTop, color: 0xd9b26b });
  const matWater = new THREE.MeshLambertMaterial({
    color: 0x3a7bd5,
    transparent: true,
    opacity: 0.65,
    depthWrite: false,
  });
  const matBedrock = new THREE.MeshLambertMaterial({ map: stone, color: 0x555555 });

  // BoxGeometry face order: px, nx, py, ny, pz, nz
  const grassArr = [matGrassSide, matGrassSide, matGrassTop, matDirt, matGrassSide, matGrassSide];
  const woodArr = [matWoodSide, matWoodSide, matWoodTop, matWoodTop, matWoodSide, matWoodSide];

  return {
    byType: {
      [BlockType.GRASS]: grassArr,
      [BlockType.DIRT]: matDirt,
      [BlockType.STONE]: matStone,
      [BlockType.SAND]: matSand,
      [BlockType.WOOD]: woodArr,
      [BlockType.LEAVES]: matLeaves,
      [BlockType.WATER]: matWater,
      [BlockType.BEDROCK]: matBedrock,
      [BlockType.PLANK]: matPlank,
    },
  };
}
