import { useEffect, useState } from "react";
import MinecraftGame from "./components/MinecraftGame";

export default function App() {
  const [started, setStarted] = useState(false);

  useEffect(() => {
    // 防止移动端双指缩放/橡皮筋滚动影响游戏体验
    const preventDefault = (e: TouchEvent) => {
      if (e.touches.length > 1) e.preventDefault();
    };
    document.addEventListener("touchmove", preventDefault, { passive: false });
    document.addEventListener("gesturestart", (e) => e.preventDefault());
    return () => {
      document.removeEventListener("touchmove", preventDefault);
    };
  }, []);

  return (
    <div
      className="fixed inset-0 h-[100dvh] w-screen overflow-hidden bg-black"
      style={{ touchAction: "none", overscrollBehavior: "none" }}
    >
      {!started ? (
        <StartScreen onStart={() => setStarted(true)} />
      ) : (
        <MinecraftGame />
      )}
    </div>
  );
}

function StartScreen({ onStart }: { onStart: () => void }) {
  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-sky-400 via-sky-500 to-emerald-600 px-6 text-center">
      <div
        className="pointer-events-none absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.15) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />
      <h1
        className="mb-2 text-5xl font-black tracking-tight text-white drop-shadow-[3px_3px_0_rgba(0,0,0,0.35)]"
        style={{ fontFamily: "'Segoe UI', system-ui, sans-serif" }}
      >
        方块世界
      </h1>
      <p className="mb-8 text-sm font-medium text-white/90 drop-shadow">手机网页版沙盒建造游戏 · 灵感来自 Minecraft</p>

      <button
        onClick={onStart}
        className="mb-4 rounded-lg border-b-4 border-emerald-800 bg-emerald-500 px-10 py-4 text-xl font-bold text-white shadow-lg active:translate-y-0.5 active:border-b-2"
      >
        开始游戏
      </button>

      <div className="mt-6 max-w-xs rounded-lg bg-black/25 p-4 text-left text-xs leading-relaxed text-white/90">
        <p className="mb-1 font-bold">操作说明:</p>
        <p>🕹 左下摇杆:移动角色</p>
        <p>👆 右侧屏幕拖动:环顾视角</p>
        <p>⛏ 长按红色按钮:挖掘方块</p>
        <p>▦ 点击蓝色按钮:放置方块</p>
        <p>跳 绿色按钮:跳跃</p>
        <p>📦 底部栏:选择要放置的方块</p>
      </div>

      <p className="mt-6 text-[11px] text-white/70">建议使用竖屏或横屏浏览器全屏体验</p>
    </div>
  );
}
