import { useRef, useState, MutableRefObject, useCallback } from "react";
import { InputState } from "../game/input";
import { BlockType, BLOCK_INFO, HOTBAR_BLOCKS } from "../game/blocks";

interface GameUIProps {
  input: MutableRefObject<InputState>;
  selected: BlockType;
  onSelect: (b: BlockType) => void;
  progressRef: MutableRefObject<HTMLDivElement | null>;
  crosshairRef: MutableRefObject<HTMLDivElement | null>;
  loading: boolean;
  loadingText: string;
}

export default function GameUI({
  input,
  selected,
  onSelect,
  progressRef,
  crosshairRef,
  loading,
  loadingText,
}: GameUIProps) {
  return (
    <div className="absolute inset-0 select-none" style={{ touchAction: "none" }}>
      {loading && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-b from-sky-400 to-sky-700 text-white">
          <div className="mb-4 h-14 w-14 animate-spin rounded-md border-4 border-white/30 border-t-white" />
          <div className="text-lg font-bold tracking-wide drop-shadow">{loadingText}</div>
          <div className="mt-1 text-xs text-white/70">世界生成中,请稍候…</div>
        </div>
      )}

      {!loading && <LookLayer input={input} />}
      {!loading && <Joystick input={input} />}

      {/* 十字准星 */}
      <div
        ref={crosshairRef}
        className="pointer-events-none absolute left-1/2 top-1/2 z-20 h-6 w-6 -translate-x-1/2 -translate-y-1/2 transition-colors"
      >
        <div className="absolute left-1/2 top-1/2 h-0.5 w-4 -translate-x-1/2 -translate-y-1/2 bg-white/90 shadow" />
        <div className="absolute left-1/2 top-1/2 h-4 w-0.5 -translate-x-1/2 -translate-y-1/2 bg-white/90 shadow" />
      </div>

      {/* 挖掘进度条 */}
      <div className="pointer-events-none absolute left-1/2 top-[calc(50%+22px)] z-20 h-1.5 w-16 -translate-x-1/2 overflow-hidden rounded-full bg-black/30">
        <div ref={progressRef} className="h-full w-0 bg-white" />
      </div>

      {!loading && (
        <>
          <RightButtons input={input} />
          <Hotbar selected={selected} onSelect={onSelect} />
          <div className="pointer-events-none absolute left-2 top-2 z-30 rounded bg-black/30 px-2 py-1 text-[10px] text-white/80">
            左侧摇杆移动 · 右侧滑动视角 · 长按⛏挖掘 · 点击▦放置
          </div>
        </>
      )}
    </div>
  );
}

function LookLayer({ input }: { input: MutableRefObject<InputState> }) {
  const touchId = useRef<number | null>(null);
  const last = useRef({ x: 0, y: 0 });

  const onStart = useCallback((e: React.TouchEvent) => {
    const t = e.changedTouches[0];
    touchId.current = t.identifier;
    last.current = { x: t.clientX, y: t.clientY };
  }, []);

  const onMove = useCallback(
    (e: React.TouchEvent) => {
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (t.identifier === touchId.current) {
          const dx = t.clientX - last.current.x;
          const dy = t.clientY - last.current.y;
          last.current = { x: t.clientX, y: t.clientY };
          input.current.lookDX += dx;
          input.current.lookDY += dy;
        }
      }
    },
    [input]
  );

  const onEnd = useCallback((e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchId.current) {
        touchId.current = null;
      }
    }
  }, []);

  return (
    <div
      className="absolute inset-0 z-10"
      style={{ touchAction: "none" }}
      onTouchStart={onStart}
      onTouchMove={onMove}
      onTouchEnd={onEnd}
      onTouchCancel={onEnd}
    />
  );
}

function Joystick({ input }: { input: MutableRefObject<InputState> }) {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const touchId = useRef<number | null>(null);
  const baseRef = useRef<HTMLDivElement | null>(null);
  const center = useRef({ x: 0, y: 0 });
  const RADIUS = 45;

  const onStart = useCallback((e: React.TouchEvent) => {
    const t = e.changedTouches[0];
    touchId.current = t.identifier;
    const rect = baseRef.current!.getBoundingClientRect();
    center.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    updateFromTouch(t.clientX, t.clientY);
  }, []);

  const updateFromTouch = (clientX: number, clientY: number) => {
    let dx = clientX - center.current.x;
    let dy = clientY - center.current.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > RADIUS) {
      dx = (dx / dist) * RADIUS;
      dy = (dy / dist) * RADIUS;
    }
    setKnob({ x: dx, y: dy });
    input.current.moveX = dx / RADIUS;
    input.current.moveY = -dy / RADIUS;
  };

  const onMove = useCallback((e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === touchId.current) {
        updateFromTouch(t.clientX, t.clientY);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onEnd = useCallback((e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchId.current) {
        touchId.current = null;
        setKnob({ x: 0, y: 0 });
        input.current.moveX = 0;
        input.current.moveY = 0;
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      ref={baseRef}
      className="absolute bottom-24 left-6 z-20 h-[110px] w-[110px] rounded-full border-2 border-white/40 bg-white/10 backdrop-blur-sm"
      style={{ touchAction: "none" }}
      onTouchStart={onStart}
      onTouchMove={onMove}
      onTouchEnd={onEnd}
      onTouchCancel={onEnd}
    >
      <div
        className="absolute left-1/2 top-1/2 h-12 w-12 rounded-full bg-white/70 shadow-md"
        style={{ transform: `translate(-50%, -50%) translate(${knob.x}px, ${knob.y}px)` }}
      />
    </div>
  );
}

function RightButtons({ input }: { input: MutableRefObject<InputState> }) {
  const setBreaking = (v: boolean) => (e: React.TouchEvent) => {
    e.preventDefault();
    input.current.breaking = v;
  };
  const doPlace = (e: React.TouchEvent) => {
    e.preventDefault();
    input.current.place = true;
  };
  const setJump = (v: boolean) => (e: React.TouchEvent) => {
    e.preventDefault();
    input.current.jump = v;
  };

  return (
    <div className="absolute bottom-24 right-5 z-20 flex flex-col items-end gap-3" style={{ touchAction: "none" }}>
      <button
        className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-white/50 bg-red-500/70 text-2xl text-white shadow-lg active:scale-95"
        onTouchStart={setBreaking(true)}
        onTouchEnd={setBreaking(false)}
        onTouchCancel={setBreaking(false)}
      >
        ⛏
      </button>
      <button
        className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-white/50 bg-blue-500/70 text-xl text-white shadow-lg active:scale-95"
        onTouchStart={doPlace}
      >
        ▦
      </button>
      <button
        className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-white/50 bg-emerald-500/70 text-sm font-bold text-white shadow-lg active:scale-95"
        onTouchStart={setJump(true)}
        onTouchEnd={setJump(false)}
        onTouchCancel={setJump(false)}
      >
        跳
      </button>
    </div>
  );
}

function Hotbar({ selected, onSelect }: { selected: BlockType; onSelect: (b: BlockType) => void }) {
  return (
    <div
      className="absolute bottom-3 left-1/2 z-20 flex -translate-x-1/2 gap-1 rounded-lg border border-white/30 bg-black/30 p-1.5"
      style={{ touchAction: "none" }}
    >
      {HOTBAR_BLOCKS.map((b) => (
        <button
          key={b}
          onTouchStart={(e) => {
            e.preventDefault();
            onSelect(b);
          }}
          className={`flex h-11 w-11 items-center justify-center overflow-hidden rounded border-2 bg-black/40 ${
            selected === b ? "border-white" : "border-white/20"
          }`}
        >
          <img src={BLOCK_INFO[b].icon} alt={BLOCK_INFO[b].name} className="h-full w-full object-cover" draggable={false} />
        </button>
      ))}
    </div>
  );
}
