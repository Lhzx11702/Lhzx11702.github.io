import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { World } from "../game/world";
import { buildMaterials } from "../game/textures";
import { buildInstancedMeshes } from "../game/meshBuilder";
import { raycastVoxel } from "../game/raycast";
import { createInputState } from "../game/input";
import { tryMove, EYE_HEIGHT, GRAVITY, JUMP_SPEED, WALK_SPEED } from "../game/physics";
import { BlockType, BLOCK_INFO } from "../game/blocks";
import GameUI from "./GameUI";

export default function MinecraftGame() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef(createInputState());
  const progressRef = useRef<HTMLDivElement | null>(null);
  const crosshairRef = useRef<HTMLDivElement | null>(null);
  const [selected, setSelected] = useState<BlockType>(BlockType.GRASS);
  const selectedRef = useRef(selected);
  const [loading, setLoading] = useState(true);
  const loadingText = "正在生成方块世界…";

  useEffect(() => {
    selectedRef.current = selected;
  }, [selected]);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    let disposed = false;
    let animId = 0;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x8fd1f5);
    scene.fog = new THREE.Fog(0x8fd1f5, 30, 85);

    const camera = new THREE.PerspectiveCamera(
      72,
      mount.clientWidth / mount.clientHeight,
      0.05,
      200
    );
    camera.rotation.order = "YXZ";

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    mount.appendChild(renderer.domElement);

    const hemi = new THREE.HemisphereLight(0xbfe3ff, 0x4a6b3a, 1.0);
    scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xfff3d6, 1.0);
    sun.position.set(60, 90, 40);
    scene.add(sun);
    const ambient = new THREE.AmbientLight(0xffffff, 0.25);
    scene.add(ambient);

    // 高亮方块边框
    const highlightGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.01, 1.01, 1.01));
    const highlightMat = new THREE.LineBasicMaterial({ color: 0x000000, linewidth: 2 });
    const highlight = new THREE.LineSegments(highlightGeo, highlightMat);
    highlight.visible = false;
    scene.add(highlight);

    const boxGeometry = new THREE.BoxGeometry(1, 1, 1);
    let instancedMeshes: THREE.InstancedMesh[] = [];

    const world = new World();
    const materials = buildMaterials();

    // 玩家状态
    const player = { x: 0, y: 20, z: 0 };
    let velocityY = 0;
    let grounded = false;
    let yaw = Math.PI;
    let pitch = -0.15;

    let breakingProgress = 0;
    let breakingTarget: string | null = null;

    function rebuildMeshes() {
      for (const m of instancedMeshes) {
        scene.remove(m);
        m.dispose();
      }
      instancedMeshes = buildInstancedMeshes(world, materials, boxGeometry);
      for (const m of instancedMeshes) scene.add(m);
    }

    // 异步生成世界,避免阻塞 loading 界面绘制
    const genTimer = window.setTimeout(() => {
      world.generate();
      const spawn = world.findSpawn();
      player.x = spawn.x;
      player.y = spawn.y;
      player.z = spawn.z;
      rebuildMeshes();
      if (!disposed) setLoading(false);
    }, 60);

    function onResize() {
      if (!mount) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    }
    window.addEventListener("resize", onResize);

    const clock = new THREE.Clock();
    const forwardVec = new THREE.Vector3();
    const rightVec = new THREE.Vector3();
    const moveVec = new THREE.Vector3();
    const rayDir = new THREE.Vector3();
    const rayOrigin = new THREE.Vector3();

    function loop() {
      animId = requestAnimationFrame(loop);
      const dt = Math.min(clock.getDelta(), 0.06);
      const input = inputRef.current;

      // 视角
      const sensitivity = 0.0032;
      yaw -= input.lookDX * sensitivity;
      pitch -= input.lookDY * sensitivity;
      const maxPitch = Math.PI / 2 - 0.02;
      pitch = Math.max(-maxPitch, Math.min(maxPitch, pitch));
      input.lookDX = 0;
      input.lookDY = 0;
      camera.rotation.y = yaw;
      camera.rotation.x = pitch;

      // 移动方向 (仅使用 yaw)
      forwardVec.set(-Math.sin(yaw), 0, -Math.cos(yaw));
      rightVec.set(Math.cos(yaw), 0, -Math.sin(yaw));
      moveVec.set(0, 0, 0);
      moveVec.addScaledVector(forwardVec, input.moveY);
      moveVec.addScaledVector(rightVec, input.moveX);
      if (moveVec.lengthSq() > 1) moveVec.normalize();

      const dx = moveVec.x * WALK_SPEED * dt;
      const dz = moveVec.z * WALK_SPEED * dt;

      velocityY -= GRAVITY * dt;
      if (velocityY < -40) velocityY = -40;
      if (input.jump && grounded) {
        velocityY = JUMP_SPEED;
        grounded = false;
      }
      const dy = velocityY * dt;

      const result = tryMove(world, player, dx, dy, dz);
      player.x = result.pos.x;
      player.y = result.pos.y;
      player.z = result.pos.z;
      if (result.collidedY) {
        if (result.collidedYNegative) grounded = true;
        velocityY = 0;
      } else {
        grounded = false;
      }

      // 掉落出世界边界则重生
      if (player.y < -25) {
        const spawn = world.findSpawn();
        player.x = spawn.x;
        player.y = spawn.y;
        player.z = spawn.z;
        velocityY = 0;
      }

      camera.position.set(player.x, player.y + EYE_HEIGHT, player.z);

      // 射线检测目标方块
      rayOrigin.copy(camera.position);
      camera.getWorldDirection(rayDir);
      const target = raycastVoxel(rayOrigin, rayDir, world, 6);

      if (target) {
        highlight.visible = true;
        highlight.position.set(target.block.x, target.block.y, target.block.z);
        if (crosshairRef.current) crosshairRef.current.style.opacity = "1";
      } else {
        highlight.visible = false;
        if (crosshairRef.current) crosshairRef.current.style.opacity = "0.5";
      }

      // 挖掘
      const targetKey = target ? `${target.block.x},${target.block.y},${target.block.z}` : null;
      if (target && input.breaking) {
        if (breakingTarget !== targetKey) {
          breakingTarget = targetKey;
          breakingProgress = 0;
        }
        const hardness = BLOCK_INFO[target.type]?.hardness ?? 0.6;
        breakingProgress += dt;
        const pct = Math.min(1, breakingProgress / hardness);
        if (progressRef.current) progressRef.current.style.width = `${pct * 100}%`;
        if (pct >= 1) {
          world.setBlock(target.block.x, target.block.y, target.block.z, BlockType.AIR);
          rebuildMeshes();
          breakingProgress = 0;
          breakingTarget = null;
          if (progressRef.current) progressRef.current.style.width = "0%";
        }
      } else {
        breakingTarget = null;
        breakingProgress = 0;
        if (progressRef.current) progressRef.current.style.width = "0%";
      }

      // 放置
      if (input.place) {
        input.place = false;
        if (target) {
          const p = target.place;
          const free = world.getBlock(p.x, p.y, p.z) === BlockType.AIR;
          const overlapsPlayer = isPlaceInsidePlayer(player, p);
          if (free && !overlapsPlayer) {
            world.setBlock(p.x, p.y, p.z, selectedRef.current);
            rebuildMeshes();
          }
        }
      }

      renderer.render(scene, camera);
    }

    function isPlaceInsidePlayer(p: { x: number; y: number; z: number }, block: { x: number; y: number; z: number }) {
      const px0 = p.x - 0.3,
        px1 = p.x + 0.3;
      const pz0 = p.z - 0.3,
        pz1 = p.z + 0.3;
      const py0 = p.y,
        py1 = p.y + 1.75;
      const bx0 = block.x - 0.5,
        bx1 = block.x + 0.5;
      const by0 = block.y - 0.5,
        by1 = block.y + 0.5;
      const bz0 = block.z - 0.5,
        bz1 = block.z + 0.5;
      return px0 < bx1 && px1 > bx0 && py0 < by1 && py1 > by0 && pz0 < bz1 && pz1 > bz0;
    }

    loop();

    return () => {
      disposed = true;
      window.clearTimeout(genTimer);
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", onResize);
      for (const m of instancedMeshes) m.dispose();
      boxGeometry.dispose();
      highlightGeo.dispose();
      highlightMat.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement === mount) {
        mount.removeChild(renderer.domElement);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="relative h-full w-full overflow-hidden bg-sky-400">
      <div ref={mountRef} className="absolute inset-0" />
      <GameUI
        input={inputRef}
        selected={selected}
        onSelect={setSelected}
        progressRef={progressRef}
        crosshairRef={crosshairRef}
        loading={loading}
        loadingText={loadingText}
      />
    </div>
  );
}
